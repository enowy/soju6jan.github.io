# -*- coding: utf-8 -*-
import os
import xbmc, xbmcaddon

__addon__ = xbmcaddon.Addon()
__version__ = __addon__.getAddonInfo('version')
__id__ = __addon__.getAddonInfo('id')

__profile__ = xbmc.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
LOCAL_PROGRAM_LIST = xbmc.translatePath(os.path.join( __profile__, 'programlist.txt'))
LOGINDATA = xbmc.translatePath(os.path.join( __profile__, 'login.dat'))

def LOG(str):
	try:
		xbmc.log("[%s-%s]: %s" %(__id__, __version__, str), level=xbmc.LOGNOTICE)
		log_message = str.encode('utf-8', 'ignore')
	except:
		log_message = 'TVING Exception'
	xbmc.log("[%s-%s]: %s" %(__id__, __version__, log_message), level=xbmc.LOGNOTICE)


